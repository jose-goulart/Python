n = int(input("Digite um inteiro: "))
square = 0
i = 0
while(i <= n):
    square += i * i
    i += 1
print(square)
